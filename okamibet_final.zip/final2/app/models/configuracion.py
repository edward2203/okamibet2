import time
from app.database import get_db, release_db

# ==================== CACHE DE CONFIGURACIÓN ====================
_config_cache = {}
_config_cache_ttl = 60  
_config_cache_timestamp = 0

def _config_cache_valida():
    return (time.time() - _config_cache_timestamp) < _config_cache_ttl

def get_config_batch(claves):
    """Obtiene múltiples configuraciones (Optimizado para Postgres + Caché)"""
    global _config_cache, _config_cache_timestamp

    # 1. Intentar servir desde caché
    if _config_cache_valida():
        resultado = {c: _config_cache[c] for c in claves if c in _config_cache}
        faltantes = [c for c in claves if c not in _config_cache]
        if not faltantes:
            return resultado
        claves_a_buscar = faltantes
    else:
        _config_cache.clear()
        resultado = {}
        claves_a_buscar = claves

    # 2. Consulta a PostgreSQL
    conn = get_db()
    try:
        cursor = conn.cursor()
        # En Postgres es más eficiente usar ANY(%s) que generar placeholders dinámicos
        cursor.execute("SELECT clave, valor FROM configuraciones WHERE clave = ANY(%s)", (list(claves_a_buscar),))
        
        for row in cursor.fetchall():
            clave_db, valor_db = row[0], row[1]
            resultado[clave_db] = valor_db
            _config_cache[clave_db] = valor_db
            
        _config_cache_timestamp = time.time()
        return resultado
    finally:
        release_db(conn)

def get_config(clave, default=""):
    """Obtiene un valor individual con lógica de caché"""
    global _config_cache, _config_cache_timestamp

    if _config_cache_valida() and clave in _config_cache:
        return _config_cache[clave]

    conn = get_db()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT valor FROM configuraciones WHERE clave = %s", (clave,))
        row = cursor.fetchone()
        valor = row[0] if row else default
        
        _config_cache[clave] = valor
        _config_cache_timestamp = time.time()
        return valor
    finally:
        release_db(conn)

def set_config(clave, valor):
    """Actualiza o Inserta (UPSERT) en Postgres e invalida caché"""
    global _config_cache, _config_cache_timestamp

    conn = get_db()
    try:
        cursor = conn.cursor()
        # Sintaxis robusta para PostgreSQL: Si la clave existe, actualiza; si no, inserta.
        cursor.execute('''
            INSERT INTO configuraciones (clave, valor) 
            VALUES (%s, %s)
            ON CONFLICT (clave) 
            DO UPDATE SET valor = EXCLUDED.valor
        ''', (clave, str(valor)))
        
        conn.commit()
        
        # Actualizar caché local
        _config_cache[clave] = str(valor)
        _config_cache_timestamp = time.time()
    except Exception as e:
        conn.rollback()
        print(f"Error en set_config: {e}")
        raise e
    finally:
        release_db(conn)